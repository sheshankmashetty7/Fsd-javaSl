package com.example.methoddemo;
public class MethodDemo {

    // Method to calculate area of a rectangle
    public int calculateRectangleArea(int length, int width) {
        return length * width;
    }

    // Method to greet a person
    public void greet(String name) {
        System.out.println("Hello, " + name + "!");
    }

    public static void main(String[] args) {
        MethodDemo md = new MethodDemo();

        // Calling methods with arguments
        int rectangleArea = md.calculateRectangleArea(5, 4);
        System.out.println("Rectangle area: " + rectangleArea);

        // Calling methods without arguments
        md.greet("Bard");

        // Calling a method directly within another method
        System.out.println("Sum of 5 and 7: " + md.sum(5, 7));
    }

    // Method to demonstrate a method calling another method
    public int sum(int a, int b) {
        return a + b;
    }
}

