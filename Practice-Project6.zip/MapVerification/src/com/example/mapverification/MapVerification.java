package com.example.mapverification;
import java.util.HashMap;
import java.util.Map;

public class MapVerification {
    public static void main(String[] args) {
        // Create a HashMap to store key-value pairs
        Map<String, Integer> map = new HashMap<>();

        // Add some entries to the map
        map.put("apple", 5);
        map.put("banana", 3);
        map.put("orange", 2);

        // Verify basic operations
        System.out.println("Size of the map: " + map.size());
        System.out.println("Value for key 'apple': " + map.get("apple"));
        System.out.println("Contains key 'banana': " + map.containsKey("banana"));

        // Iterate over the entries
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            System.out.println(entry.getKey() + " - " + entry.getValue());
        }

        // Remove an entry
        map.remove("orange");
        System.out.println("Map after removing 'orange': " + map);
    }
}

