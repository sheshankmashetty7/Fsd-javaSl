package com.example.innerclassdemo;
public class InnerClassVerification {

    public static void main(String[] args) {
        // Create an instance of the outer class
        OuterClass outer = new OuterClass();

        // Access the inner class methods through the outer class instance
        outer.innerMethod();

        // Create an instance of the inner class using the outer class instance
        OuterClass.InnerClass inner = outer.new InnerClass();
        inner.innerClassMethod();

        // Create an instance of the static inner class directly
        OuterClass.StaticInnerClass staticInner = new OuterClass.StaticInnerClass();
        staticInner.staticInnerClassMethod();
    }
}

class OuterClass {

    private int outerValue = 10;

    public void outerMethod() {
        System.out.println("Method of the outer class");
    }

    // Inner class
    class InnerClass {

        public void innerClassMethod() {
            System.out.println("Method of the inner class");
            System.out.println("Accessing outerValue from inner class: " + outerValue);
        }
    }

    // Static inner class
    static class StaticInnerClass {

        public void staticInnerClassMethod() {
            System.out.println("Method of the static inner class");
        }
    }

    public void innerMethod() {
        InnerClass inner = new InnerClass(); // Create inner class instance within outer class method
        inner.innerClassMethod();
    }
}

