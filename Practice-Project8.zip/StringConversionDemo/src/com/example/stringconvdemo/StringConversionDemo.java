package com.example.stringconvdemo;
public class StringConversionDemo {

    public static void main(String[] args) {
        // Create a string
        String string = "Hello, world!";

        // Convert string to StringBuffer
        StringBuffer stringBuffer = new StringBuffer(string);
        System.out.println("StringBuffer: " + stringBuffer);

        // Modify the StringBuffer
        stringBuffer.append(" This is a modified StringBuffer.");
        System.out.println("Modified StringBuffer: " + stringBuffer);

        // Convert string to StringBuilder
        StringBuilder stringBuilder = new StringBuilder(string);
        System.out.println("StringBuilder: " + stringBuilder);

        // Modify the StringBuilder
        stringBuilder.insert(0, "Starting with: ");
        System.out.println("Modified StringBuilder: " + stringBuilder);
    }
}

