package com.example.collectiondemo;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.TreeSet;

public class CollectionDemo {

    public static void main(String[] args) {
        // ArrayList (ordered, duplicates allowed)
        ArrayList<String> colors = new ArrayList<>();
        colors.add("red");
        colors.add("green");
        colors.add("blue");
        colors.add("green"); // Duplicate allowed
        System.out.println("ArrayList: " + colors);

        // LinkedList (ordered, duplicates allowed, efficient for frequent insertions/deletions)
        LinkedList<Integer> numbers = new LinkedList<>();
        numbers.add(10);
        numbers.add(5);
        numbers.add(20);
        System.out.println("LinkedList: " + numbers);

        // HashSet (unordered, no duplicates)
        HashSet<String> fruits = new HashSet<>();
        fruits.add("apple");
        fruits.add("banana");
        fruits.add("apple"); // Duplicate ignored
        System.out.println("HashSet: " + fruits);

        // TreeSet (ordered, no duplicates)
        TreeSet<Integer> sortedNumbers = new TreeSet<>();
        sortedNumbers.add(3);
        sortedNumbers.add(1);
        sortedNumbers.add(5);
        System.out.println("TreeSet: " + sortedNumbers);
    }
}
