package com.example.arrayverification;
import java.util.Arrays;
public class ArrayVerification {
    public static void main(String[] args) {
        // Declare and initialize an array of integers
        int[] numbers = {10, 25, 15, 8, 32};

        // Access and print individual elements
        System.out.println("First element: " + numbers[0]);
        System.out.println("Third element: " + numbers[2]);

        // Modify an element
        numbers[4] = 40;
        System.out.println("Array after modification: " + Arrays.toString(numbers));

        // Iterate through the array using a for loop
        for (int i = 0; i < numbers.length; i++) {
            System.out.print(numbers[i] + " ");
        }
        System.out.println();

        // Iterate through the array using the enhanced for loop
        for (int number : numbers) {
            System.out.print(number + " ");
        }
        System.out.println();
    }
}
