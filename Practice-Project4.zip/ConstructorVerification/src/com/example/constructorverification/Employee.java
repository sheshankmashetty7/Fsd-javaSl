package com.example.constructorverification;
public class Employee {

    // Instance variables
    private String name;
    private int age;
    private double salary;

    // Default constructor (no arguments)
    public Employee() {
        System.out.println("Default constructor called.");
    }

    // Parameterized constructor (with arguments)
    public Employee(String name, int age, double salary) {
        this.name = name;
        this.age = age;
        this.salary = salary;
        System.out.println("Parameterized constructor called.");
    }

    // Copy constructor (creates a new object from an existing object)
    public Employee(Employee emp) {
        this.name = emp.name;
        this.age = emp.age;
        this.salary = emp.salary;
        System.out.println("Copy constructor called.");
    }

    public void displayInfo() {
        System.out.println("Name: " + name + ", Age: " + age + ", Salary: " + salary);
    }

    public static void main(String[] args) {
        // Creating objects using different constructors
        Employee emp1 = new Employee();  // Calls default constructor
        Employee emp2 = new Employee("Rahul", 30, 50000);  // Calls parameterized constructor
        Employee emp3 = new Employee(emp2);  // Calls copy constructor

        // Outputting employee information
        emp1.displayInfo();
        emp2.displayInfo();
        emp3.displayInfo();
    }
}

