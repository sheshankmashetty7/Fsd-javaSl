package com.example.accessmodifiers;
public class Employee {
    public String publicName;
    protected double protectedSalary;
    private int privateAge;

    public void publicMethod() {
        System.out.println("Public method accessed.");
    }

    protected void protectedMethod() {
        System.out.println("Protected method accessed.");
    }

    public int getPrivateAge() {
		return privateAge;
	}

	public void setPrivateAge(int privateAge) {
		this.privateAge = privateAge;
	}
}
