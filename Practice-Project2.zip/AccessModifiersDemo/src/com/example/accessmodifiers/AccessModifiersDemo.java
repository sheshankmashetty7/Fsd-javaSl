package com.example.accessmodifiers;
public class AccessModifiersDemo {
    public static void main(String[] args) {
        Employee emp = new Employee();

        // Accessing public members
        emp.publicName = "John Doe";
        emp.publicMethod();

        // Accessing protected members (within the same package)
        emp.protectedSalary = 50000;
        emp.protectedMethod();

        // Attempting to access private members (will result in errors)
        // emp.privateAge = 30;  // Error: private member cannot be accessed
        // emp.privateMethod();  // Error: private member cannot be accessed
    }
}
