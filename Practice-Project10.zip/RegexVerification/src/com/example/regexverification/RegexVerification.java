package com.example.regexverification;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegexVerification {

    public static void main(String[] args) {
        // Define regular expressions for different patterns
        String emailRegex = "^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\\.[a-zA-Z0-9-.]+$";
        String phoneRegex = "\\d{10}";
        String passwordRegex = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)[a-zA-Z\\d]{8,}$";  // At least 8 characters, 1 uppercase, 1 lowercase, 1 digit

        // Test strings for matching
        String email = "john.doe@example.com";
        String phone = "1234567890";
        String password = "Password123";

        // Verify email format
        Pattern emailPattern = Pattern.compile(emailRegex);
        Matcher emailMatcher = emailPattern.matcher(email);
        System.out.println("Email is valid: " + emailMatcher.matches());

        // Verify phone number format
        Pattern phonePattern = Pattern.compile(phoneRegex);
        Matcher phoneMatcher = phonePattern.matcher(phone);
        System.out.println("Phone number is valid: " + phoneMatcher.matches());

        // Verify password strength
        Pattern passwordPattern = Pattern.compile(passwordRegex);
        Matcher passwordMatcher = passwordPattern.matcher(password);
        System.out.println("Password meets strength requirements: " + passwordMatcher.matches());
    }
}

