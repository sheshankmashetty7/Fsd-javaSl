/**
 * 
 */
/**
 * 
 */
module TypeCastingExample {
}