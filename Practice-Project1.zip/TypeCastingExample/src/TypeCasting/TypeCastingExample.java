package TypeCasting;
public class TypeCastingExample {
    public static void main(String[] args) {
        // Implicit type casting (widening)
        byte b = 127;
        short s = b;  // Automatic conversion from byte to short
        int i = s;   // Automatic conversion from short to int
        long l = i;   // Automatic conversion from int to long
        float f = l;  // Automatic conversion from long to float
        double d = f; // Automatic conversion from float to double

        System.out.println("Implicit Type Casting:");
        System.out.println("byte value: " + b);
        System.out.println("short value: " + s);
        System.out.println("int value: " + i);
        System.out.println("long value: " + l);
        System.out.println("float value: " + f);
        System.out.println("double value: " + d);

        // Explicit type casting (narrowing)
        double doubleValue = 123.456;
        int intValue = (int) doubleValue;  // Explicit conversion from double to int

        System.out.println("\nExplicit Type Casting:");
        System.out.println("double value: " + doubleValue);
        System.out.println("int value (after casting): " + intValue);
    }
}